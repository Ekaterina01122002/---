package com.library.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Класс выдачи - связывает библиотечную единицу с информацией о выдаче.
 * Использует агрегацию вместо наследования.
 */
public class TLoan {

    /** Выданная библиотечная единица */
    private TLibraryItem item;

    /** Дата выдачи */
    private LocalDate issueDate;

    /** Предполагаемая дата возврата */
    private LocalDate returnDate;

    /** Фактическая дата возврата (null если не возвращена) */
    private LocalDate actualReturnDate;

    /** Штраф за просрочку */
    private static final int PENALTY_PER_DAY = 1;

    /**
     * Создает новую выдачу.
     *
     * @param item библиотечная единица
     * @param loanPeriodDays срок выдачи в днях
     */
    public TLoan(TLibraryItem item, int loanPeriodDays) {
        this.item = item;
        this.issueDate = LocalDate.now();
        this.returnDate = issueDate.plusDays(loanPeriodDays);
        this.actualReturnDate = null;
    }

    /**
     * Проверяет, просрочена ли выдача.
     *
     * @return true если просрочена
     */
    public boolean isOverdue() {
        LocalDate checkDate = actualReturnDate != null ? actualReturnDate : LocalDate.now();
        return checkDate.isAfter(returnDate);
    }

    /**
     * Рассчитывает штрафные баллы.
     *
     * @return количество штрафных баллов
     */
    public int calculatePenalty() {
        LocalDate checkDate = actualReturnDate != null ? actualReturnDate : LocalDate.now();
        long daysOverdue = ChronoUnit.DAYS.between(returnDate, checkDate);

        if (daysOverdue > 0) {
            return (int) daysOverdue * PENALTY_PER_DAY;
        }
        return 0;
    }

    /**
     * Закрывает выдачу (возврат единицы).
     *
     * @return начисленный штраф
     */
    public int close() {
        this.actualReturnDate = LocalDate.now();
        return calculatePenalty();
    }

    /**
     * Проверяет, активна ли выдача.
     *
     * @return true если единица ещё не возвращена
     */
    public boolean isActive() {
        return actualReturnDate == null;
    }

    /**
     * Получает количество дней до возврата.
     *
     * @return дней до возврата (отрицательное если просрочено)
     */
    public long getDaysUntilReturn() {
        return ChronoUnit.DAYS.between(LocalDate.now(), returnDate);
    }

    // Геттеры

    public TLibraryItem getItem() {
        return item;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public LocalDate getActualReturnDate() {
        return actualReturnDate;
    }

    @Override
    public String toString() {
        String status = isActive() ? "активна" : "закрыта";
        return "Выдача: " + item.getDisplayName() + " [" + status +
               ", срок: " + returnDate + "]";
    }
}
