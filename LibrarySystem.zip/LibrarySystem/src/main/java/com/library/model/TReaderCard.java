package com.library.model;

import java.time.LocalDate;

/**
 * Класс карточки читателя.
 * НЕ наследует от TLibraryItem - это отдельная сущность.
 * Использует массив вместо коллекций.
 */
public class TReaderCard {

    /** Уникальный идентификатор карточки */
    private String id;

    /** ФИО читателя */
    private String readerName;

    /** Дата регистрации */
    private LocalDate registrationDate;

    /** Максимальное количество единиц на руках */
    private int maxBooks;

    /** Массив текущих выдач */
    private TLoan[] loans;

    /** Количество активных выдач */
    private int loanCount;

    /** Накопленные штрафные баллы */
    private int totalPenaltyPoints;

    /** Стандартный максимум книг */
    private static final int DEFAULT_MAX_BOOKS = 5;

    /**
     * Конструктор карточки читателя.
     *
     * @param id уникальный идентификатор
     * @param readerName ФИО читателя
     * @param maxBooks максимальное количество единиц
     */
    public TReaderCard(String id, String readerName, int maxBooks) {
        this.id = id;
        this.readerName = readerName;
        this.registrationDate = LocalDate.now();
        this.maxBooks = maxBooks;
        this.loans = new TLoan[maxBooks];
        this.loanCount = 0;
        this.totalPenaltyPoints = 0;
    }

    /**
     * Конструктор со стандартным лимитом.
     *
     * @param id уникальный идентификатор
     * @param readerName ФИО читателя
     */
    public TReaderCard(String id, String readerName) {
        this(id, readerName, DEFAULT_MAX_BOOKS);
    }

    /**
     * Проверяет, может ли читатель взять ещё одну единицу.
     *
     * @return true если может
     */
    public boolean canBorrow() {
        return loanCount < maxBooks;
    }

    /**
     * Берет библиотечную единицу.
     * Взаимодействие: читатель просит единицу выдаться ему.
     *
     * @param item библиотечная единица
     * @return результат операции
     */
    public IssueResult borrowItem(TLibraryItem item) {
        if (!canBorrow()) {
            return IssueResult.failure("Превышен лимит книг (" + loanCount + "/" + maxBooks + ")");
        }

        if (!item.canBeIssued()) {
            return IssueResult.failure("Единица недоступна. Статус: " + item.getStatus().getDisplayName());
        }

        // Просим единицу выдаться
        TLoan loan = item.issueToReader();
        if (loan == null) {
            return IssueResult.failure("Не удалось оформить выдачу");
        }

        // Добавляем выдачу в массив
        loans[loanCount] = loan;
        loanCount++;

        return IssueResult.success(
                "Выдано: " + item.getDisplayName() + ". Срок возврата: " + loan.getReturnDate(),
                item.getLoanPeriod()
        );
    }

    /**
     * Возвращает библиотечную единицу.
     * Взаимодействие: читатель возвращает единицу, единица возвращается в библиотеку.
     *
     * @param item библиотечная единица
     * @return начисленный штраф
     */
    public int returnItem(TLibraryItem item) {
        // Ищем выдачу в массиве
        int index = -1;
        for (int i = 0; i < loanCount; i++) {
            if (loans[i].getItem().equals(item)) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            return 0; // Единица не найдена у читателя
        }

        // Просим единицу вернуться в библиотеку
        int penalty = item.returnToLibrary();
        totalPenaltyPoints += penalty;

        // Удаляем выдачу из массива (сдвигаем элементы)
        for (int i = index; i < loanCount - 1; i++) {
            loans[i] = loans[i + 1];
        }
        loans[loanCount - 1] = null;
        loanCount--;

        return penalty;
    }

    /**
     * Проверяет, есть ли у читателя данная единица.
     *
     * @param item библиотечная единица
     * @return true если единица у читателя
     */
    public boolean hasItem(TLibraryItem item) {
        for (int i = 0; i < loanCount; i++) {
            if (loans[i].getItem().equals(item)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Получает количество единиц на руках.
     *
     * @return количество выдач
     */
    public int getBorrowedCount() {
        return loanCount;
    }

    /**
     * Получает выданные единицы как массив.
     *
     * @return массив библиотечных единиц
     */
    public TLibraryItem[] getBorrowedItems() {
        TLibraryItem[] items = new TLibraryItem[loanCount];
        for (int i = 0; i < loanCount; i++) {
            items[i] = loans[i].getItem();
        }
        return items;
    }

    /**
     * Получает активные выдачи как массив.
     *
     * @return массив выдач
     */
    public TLoan[] getActiveLoans() {
        TLoan[] activeLoans = new TLoan[loanCount];
        for (int i = 0; i < loanCount; i++) {
            activeLoans[i] = loans[i];
        }
        return activeLoans;
    }

    /**
     * Рассчитывает текущий штраф по всем активным выдачам.
     *
     * @return сумма штрафов
     */
    public int calculateCurrentPenalty() {
        int penalty = 0;
        for (int i = 0; i < loanCount; i++) {
            penalty += loans[i].calculatePenalty();
        }
        return penalty;
    }

    /**
     * Проверяет, есть ли просроченные выдачи.
     *
     * @return true если есть просрочки
     */
    public boolean hasOverdueItems() {
        for (int i = 0; i < loanCount; i++) {
            if (loans[i].isOverdue()) {
                return true;
            }
        }
        return false;
    }

    // Геттеры и сеттеры

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReaderName() {
        return readerName;
    }

    public void setReaderName(String readerName) {
        this.readerName = readerName;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }

    public int getMaxBooks() {
        return maxBooks;
    }

    public void setMaxBooks(int maxBooks) {
        if (maxBooks >= loanCount) {
            // Пересоздаем массив если нужно
            if (maxBooks != this.maxBooks) {
                TLoan[] newLoans = new TLoan[maxBooks];
                for (int i = 0; i < loanCount; i++) {
                    newLoans[i] = loans[i];
                }
                this.loans = newLoans;
            }
            this.maxBooks = maxBooks;
        }
    }

    public int getTotalPenaltyPoints() {
        return totalPenaltyPoints;
    }

    @Override
    public String toString() {
        return "Читатель: " + readerName + " | Карточка: " + id +
               " | Книг: " + loanCount + "/" + maxBooks;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        TReaderCard that = (TReaderCard) obj;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
