package com.library.model;

import java.util.UUID;

/**
 * Класс библиотеки - управляет взаимодействием объектов.
 * Использует массивы вместо коллекций.
 */
public class TLibrary {

    /** Название библиотеки */
    private String name;

    /** Массив книг */
    private TBook[] books;
    private int bookCount;

    /** Массив журналов */
    private TJournal[] journals;
    private int journalCount;

    /** Массив карточек читателей */
    private TReaderCard[] readers;
    private int readerCount;

    /** Начальный размер массивов */
    private static final int INITIAL_CAPACITY = 100;

    /**
     * Создает новую библиотеку.
     *
     * @param name название библиотеки
     */
    public TLibrary(String name) {
        this.name = name;
        this.books = new TBook[INITIAL_CAPACITY];
        this.journals = new TJournal[INITIAL_CAPACITY];
        this.readers = new TReaderCard[INITIAL_CAPACITY];
        this.bookCount = 0;
        this.journalCount = 0;
        this.readerCount = 0;
    }

    /**
     * Генерирует уникальный идентификатор.
     *
     * @return уникальный ID
     */
    public String generateId() {
        return UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    // === Регистрация единиц ===

    /**
     * Регистрирует книгу в библиотеке.
     *
     * @param book книга для регистрации
     * @return true если успешно
     */
    public boolean registerBook(TBook book) {
        if (book == null) return false;

        // Проверяем, не зарегистрирована ли уже
        if (findBookById(book.getId()) != null) {
            return false;
        }

        // Расширяем массив если нужно
        if (bookCount >= books.length) {
            expandBooks();
        }

        books[bookCount] = book;
        bookCount++;
        return true;
    }

    /**
     * Регистрирует журнал в библиотеке.
     *
     * @param journal журнал для регистрации
     * @return true если успешно
     */
    public boolean registerJournal(TJournal journal) {
        if (journal == null) return false;

        if (findJournalById(journal.getId()) != null) {
            return false;
        }

        if (journalCount >= journals.length) {
            expandJournals();
        }

        journals[journalCount] = journal;
        journalCount++;
        return true;
    }

    /**
     * Регистрирует читателя в библиотеке.
     *
     * @param reader карточка читателя
     * @return true если успешно
     */
    public boolean registerReader(TReaderCard reader) {
        if (reader == null) return false;

        if (findReaderById(reader.getId()) != null) {
            return false;
        }

        if (readerCount >= readers.length) {
            expandReaders();
        }

        readers[readerCount] = reader;
        readerCount++;
        return true;
    }

    // === Удаление единиц ===

    /**
     * Удаляет книгу из библиотеки.
     *
     * @param book книга для удаления
     * @return true если успешно
     */
    public boolean removeBook(TBook book) {
        if (book == null || book.getStatus() == ItemStatus.ISSUED) {
            return false;
        }

        int index = findBookIndex(book);
        if (index == -1) return false;

        // Сдвигаем элементы
        for (int i = index; i < bookCount - 1; i++) {
            books[i] = books[i + 1];
        }
        books[bookCount - 1] = null;
        bookCount--;
        return true;
    }

    /**
     * Удаляет журнал из библиотеки.
     *
     * @param journal журнал для удаления
     * @return true если успешно
     */
    public boolean removeJournal(TJournal journal) {
        if (journal == null || journal.getStatus() == ItemStatus.ISSUED) {
            return false;
        }

        int index = findJournalIndex(journal);
        if (index == -1) return false;

        for (int i = index; i < journalCount - 1; i++) {
            journals[i] = journals[i + 1];
        }
        journals[journalCount - 1] = null;
        journalCount--;
        return true;
    }

    /**
     * Удаляет читателя из библиотеки.
     *
     * @param reader карточка читателя
     * @return true если успешно
     */
    public boolean removeReader(TReaderCard reader) {
        if (reader == null || reader.getBorrowedCount() > 0) {
            return false;
        }

        int index = findReaderIndex(reader);
        if (index == -1) return false;

        for (int i = index; i < readerCount - 1; i++) {
            readers[i] = readers[i + 1];
        }
        readers[readerCount - 1] = null;
        readerCount--;
        return true;
    }

    // === Операции выдачи/возврата (взаимодействие объектов) ===

    /**
     * Выдает единицу читателю.
     * Библиотека координирует взаимодействие между читателем и единицей.
     *
     * @param item библиотечная единица
     * @param reader карточка читателя
     * @return результат операции
     */
    public IssueResult issueItem(TLibraryItem item, TReaderCard reader) {
        if (item == null || reader == null) {
            return IssueResult.failure("Неверные параметры");
        }

        // Проверяем, зарегистрированы ли в библиотеке
        if (!isItemRegistered(item)) {
            return IssueResult.failure("Единица не зарегистрирована в библиотеке");
        }

        if (findReaderById(reader.getId()) == null) {
            return IssueResult.failure("Читатель не зарегистрирован в библиотеке");
        }

        // Делегируем взаимодействие читателю
        return reader.borrowItem(item);
    }

    /**
     * Принимает возврат единицы от читателя.
     *
     * @param item библиотечная единица
     * @param reader карточка читателя
     * @return начисленный штраф
     */
    public int returnItem(TLibraryItem item, TReaderCard reader) {
        if (item == null || reader == null) {
            return 0;
        }

        // Делегируем взаимодействие читателю
        return reader.returnItem(item);
    }

    // === Поиск ===

    /**
     * Ищет книгу по ID.
     *
     * @param id идентификатор
     * @return найденная книга или null
     */
    public TBook findBookById(String id) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getId().equals(id)) {
                return books[i];
            }
        }
        return null;
    }

    /**
     * Ищет журнал по ID.
     *
     * @param id идентификатор
     * @return найденный журнал или null
     */
    public TJournal findJournalById(String id) {
        for (int i = 0; i < journalCount; i++) {
            if (journals[i].getId().equals(id)) {
                return journals[i];
            }
        }
        return null;
    }

    /**
     * Ищет читателя по ID.
     *
     * @param id идентификатор
     * @return найденный читатель или null
     */
    public TReaderCard findReaderById(String id) {
        for (int i = 0; i < readerCount; i++) {
            if (readers[i].getId().equals(id)) {
                return readers[i];
            }
        }
        return null;
    }

    /**
     * Ищет книги по названию или автору.
     *
     * @param query строка поиска
     * @return массив найденных книг
     */
    public TBook[] searchBooks(String query) {
        String lowerQuery = query.toLowerCase();

        // Сначала считаем количество совпадений
        int count = 0;
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getTitle().toLowerCase().contains(lowerQuery) ||
                books[i].getAuthor().toLowerCase().contains(lowerQuery)) {
                count++;
            }
        }

        // Создаем массив нужного размера
        TBook[] result = new TBook[count];
        int j = 0;
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getTitle().toLowerCase().contains(lowerQuery) ||
                books[i].getAuthor().toLowerCase().contains(lowerQuery)) {
                result[j++] = books[i];
            }
        }
        return result;
    }

    /**
     * Ищет читателей по ФИО.
     *
     * @param query строка поиска
     * @return массив найденных читателей
     */
    public TReaderCard[] searchReaders(String query) {
        String lowerQuery = query.toLowerCase();

        int count = 0;
        for (int i = 0; i < readerCount; i++) {
            if (readers[i].getReaderName().toLowerCase().contains(lowerQuery)) {
                count++;
            }
        }

        TReaderCard[] result = new TReaderCard[count];
        int j = 0;
        for (int i = 0; i < readerCount; i++) {
            if (readers[i].getReaderName().toLowerCase().contains(lowerQuery)) {
                result[j++] = readers[i];
            }
        }
        return result;
    }

    /**
     * Получает доступные единицы.
     *
     * @return массив доступных единиц
     */
    public TLibraryItem[] getAvailableItems() {
        int count = 0;
        for (int i = 0; i < bookCount; i++) {
            if (books[i].canBeIssued()) count++;
        }
        for (int i = 0; i < journalCount; i++) {
            if (journals[i].canBeIssued()) count++;
        }

        TLibraryItem[] result = new TLibraryItem[count];
        int j = 0;
        for (int i = 0; i < bookCount; i++) {
            if (books[i].canBeIssued()) {
                result[j++] = books[i];
            }
        }
        for (int i = 0; i < journalCount; i++) {
            if (journals[i].canBeIssued()) {
                result[j++] = journals[i];
            }
        }
        return result;
    }

    /**
     * Получает все единицы.
     *
     * @return массив всех единиц
     */
    public TLibraryItem[] getAllItems() {
        TLibraryItem[] result = new TLibraryItem[bookCount + journalCount];
        int j = 0;
        for (int i = 0; i < bookCount; i++) {
            result[j++] = books[i];
        }
        for (int i = 0; i < journalCount; i++) {
            result[j++] = journals[i];
        }
        return result;
    }

    // === Вспомогательные методы ===

    private boolean isItemRegistered(TLibraryItem item) {
        if (item instanceof TBook) {
            return findBookById(item.getId()) != null;
        } else if (item instanceof TJournal) {
            return findJournalById(item.getId()) != null;
        }
        return false;
    }

    private int findBookIndex(TBook book) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].equals(book)) {
                return i;
            }
        }
        return -1;
    }

    private int findJournalIndex(TJournal journal) {
        for (int i = 0; i < journalCount; i++) {
            if (journals[i].equals(journal)) {
                return i;
            }
        }
        return -1;
    }

    private int findReaderIndex(TReaderCard reader) {
        for (int i = 0; i < readerCount; i++) {
            if (readers[i].equals(reader)) {
                return i;
            }
        }
        return -1;
    }

    private void expandBooks() {
        TBook[] newBooks = new TBook[books.length * 2];
        for (int i = 0; i < bookCount; i++) {
            newBooks[i] = books[i];
        }
        books = newBooks;
    }

    private void expandJournals() {
        TJournal[] newJournals = new TJournal[journals.length * 2];
        for (int i = 0; i < journalCount; i++) {
            newJournals[i] = journals[i];
        }
        journals = newJournals;
    }

    private void expandReaders() {
        TReaderCard[] newReaders = new TReaderCard[readers.length * 2];
        for (int i = 0; i < readerCount; i++) {
            newReaders[i] = readers[i];
        }
        readers = newReaders;
    }

    // === Геттеры ===

    public String getName() {
        return name;
    }

    public TBook[] getBooks() {
        TBook[] result = new TBook[bookCount];
        for (int i = 0; i < bookCount; i++) {
            result[i] = books[i];
        }
        return result;
    }

    public TJournal[] getJournals() {
        TJournal[] result = new TJournal[journalCount];
        for (int i = 0; i < journalCount; i++) {
            result[i] = journals[i];
        }
        return result;
    }

    public TReaderCard[] getReaders() {
        TReaderCard[] result = new TReaderCard[readerCount];
        for (int i = 0; i < readerCount; i++) {
            result[i] = readers[i];
        }
        return result;
    }

    public int getBookCount() {
        return bookCount;
    }

    public int getJournalCount() {
        return journalCount;
    }

    public int getReaderCount() {
        return readerCount;
    }

    @Override
    public String toString() {
        return "Библиотека: " + name + " | Книг: " + bookCount +
               " | Журналов: " + journalCount + " | Читателей: " + readerCount;
    }
}
