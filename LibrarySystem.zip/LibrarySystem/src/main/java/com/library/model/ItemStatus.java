package com.library.model;

/**
 * Перечисление статусов библиотечной единицы.
 * AVAILABLE - в наличии, доступна для выдачи
 * ISSUED - выдана читателю
 * IN_REPAIR - находится в ремонте/реставрации
 */
public enum ItemStatus {
    AVAILABLE("В наличии"),
    ISSUED("Выдана"),
    IN_REPAIR("В ремонте");

    private final String displayName;

    ItemStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
