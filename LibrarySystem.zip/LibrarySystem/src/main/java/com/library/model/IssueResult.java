package com.library.model;

/**
 * Результат операции выдачи библиотечной единицы.
 * @param success успешность операции
 * @param message сообщение о результате
 * @param penaltyPoints потенциальные штрафные баллы за просрочку
 */
public record IssueResult(boolean success, String message, int penaltyPoints) {
    
    public static IssueResult success(String message, int penaltyPoints) {
        return new IssueResult(true, message, penaltyPoints);
    }
    
    public static IssueResult failure(String message) {
        return new IssueResult(false, message, 0);
    }
}
