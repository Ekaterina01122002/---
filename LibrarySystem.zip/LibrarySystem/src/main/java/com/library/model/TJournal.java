package com.library.model;

/**
 * Класс журнала, наследник TLibraryItem.
 * Определяет поведение журнала как библиотечной единицы.
 */
public class TJournal extends TLibraryItem {

    /** Название журнала */
    private String name;

    /** Номер выпуска */
    private int issueNumber;

    /** Издательство */
    private String publisher;

    /** Срок выдачи журнала в днях (меньше чем для книг) */
    private static final int LOAN_PERIOD = 7;

    /**
     * Конструктор журнала со всеми параметрами.
     *
     * @param id уникальный идентификатор
     * @param name название журнала
     * @param issueNumber номер выпуска
     * @param publisher издательство
     */
    public TJournal(String id, String name, int issueNumber, String publisher) {
        super(id);
        this.name = name;
        this.issueNumber = issueNumber;
        this.publisher = publisher;
    }

    /**
     * Конструктор журнала с минимальными параметрами.
     *
     * @param id уникальный идентификатор
     * @param name название журнала
     * @param issueNumber номер выпуска
     */
    public TJournal(String id, String name, int issueNumber) {
        this(id, name, issueNumber, "");
    }

    @Override
    public int getLoanPeriod() {
        return LOAN_PERIOD;
    }

    @Override
    public String getDisplayName() {
        return name + " №" + issueNumber;
    }

    // Геттеры и сеттеры

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIssueNumber() {
        return issueNumber;
    }

    public void setIssueNumber(int issueNumber) {
        this.issueNumber = issueNumber;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @Override
    public String toString() {
        return "Журнал: " + name + " | Выпуск: " + issueNumber + " | Издательство: " + publisher;
    }
}
