package com.library.model;

/**
 * Класс книги, наследник TLibraryItem.
 * Определяет поведение книги как библиотечной единицы.
 */
public class TBook extends TLibraryItem {

    /** Название книги */
    private String title;

    /** Автор книги */
    private String author;

    /** ISBN номер */
    private String isbn;

    /** Количество страниц */
    private int pages;

    /** Срок выдачи книги в днях */
    private static final int LOAN_PERIOD = 14;

    /**
     * Конструктор книги со всеми параметрами.
     *
     * @param id уникальный идентификатор
     * @param title название книги
     * @param author автор книги
     * @param isbn ISBN номер
     * @param pages количество страниц
     */
    public TBook(String id, String title, String author, String isbn, int pages) {
        super(id);
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.pages = pages;
    }

    /**
     * Конструктор книги с минимальными параметрами.
     *
     * @param id уникальный идентификатор
     * @param title название книги
     * @param author автор книги
     */
    public TBook(String id, String title, String author) {
        this(id, title, author, "", 0);
    }

    @Override
    public int getLoanPeriod() {
        return LOAN_PERIOD;
    }

    @Override
    public String getDisplayName() {
        return title + " (" + author + ")";
    }

    // Геттеры и сеттеры

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    @Override
    public String toString() {
        return "Книга: " + title + " | Автор: " + author + " | ISBN: " + isbn + " | Страниц: " + pages;
    }
}
