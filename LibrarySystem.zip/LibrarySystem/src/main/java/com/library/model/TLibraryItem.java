package com.library.model;

/**
 * Абстрактный базовый класс для библиотечных единиц (книг и журналов).
 * Определяет собственное поведение единицы.
 */
public abstract class TLibraryItem {

    /** Уникальный идентификатор */
    protected String id;

    /** Текущий статус единицы */
    protected ItemStatus status;

    /** Ссылка на текущую выдачу (null если не выдана) */
    protected TLoan currentLoan;

    /**
     * Конструктор базового класса.
     *
     * @param id уникальный идентификатор
     */
    public TLibraryItem(String id) {
        this.id = id;
        this.status = ItemStatus.AVAILABLE;
        this.currentLoan = null;
    }

    /**
     * Проверяет, может ли единица быть выдана.
     *
     * @return true если единица доступна для выдачи
     */
    public boolean canBeIssued() {
        return status == ItemStatus.AVAILABLE && currentLoan == null;
    }

    /**
     * Выдает единицу - создает запись о выдаче.
     *
     * @return созданная выдача или null если невозможно выдать
     */
    public TLoan issueToReader() {
        if (!canBeIssued()) {
            return null;
        }

        this.currentLoan = new TLoan(this, getLoanPeriod());
        this.status = ItemStatus.ISSUED;
        return this.currentLoan;
    }

    /**
     * Возвращает единицу в библиотеку.
     *
     * @return начисленный штраф (0 если не было просрочки)
     */
    public int returnToLibrary() {
        if (currentLoan == null || status != ItemStatus.ISSUED) {
            return 0;
        }

        int penalty = currentLoan.close();
        this.currentLoan = null;
        this.status = ItemStatus.AVAILABLE;
        return penalty;
    }

    /**
     * Отправляет единицу в ремонт.
     *
     * @return true если успешно
     */
    public boolean sendToRepair() {
        if (status == ItemStatus.ISSUED) {
            return false;
        }
        this.status = ItemStatus.IN_REPAIR;
        return true;
    }

    /**
     * Возвращает единицу из ремонта.
     */
    public void returnFromRepair() {
        if (status == ItemStatus.IN_REPAIR) {
            this.status = ItemStatus.AVAILABLE;
        }
    }

    /**
     * Проверяет, просрочена ли текущая выдача.
     *
     * @return true если выдача просрочена
     */
    public boolean isOverdue() {
        return currentLoan != null && currentLoan.isOverdue();
    }

    /**
     * Получает текущий штраф за просрочку.
     *
     * @return штрафные баллы
     */
    public int getCurrentPenalty() {
        return currentLoan != null ? currentLoan.calculatePenalty() : 0;
    }

    /**
     * Получение срока выдачи в днях.
     *
     * @return срок выдачи в днях
     */
    public abstract int getLoanPeriod();

    /**
     * Получение отображаемого названия единицы.
     *
     * @return название для отображения
     */
    public abstract String getDisplayName();

    // Геттеры и сеттеры

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ItemStatus getStatus() {
        return status;
    }

    public void setStatus(ItemStatus status) {
        this.status = status;
    }

    public TLoan getCurrentLoan() {
        return currentLoan;
    }

    @Override
    public String toString() {
        return getDisplayName() + " [" + id + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        TLibraryItem that = (TLibraryItem) obj;
        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
