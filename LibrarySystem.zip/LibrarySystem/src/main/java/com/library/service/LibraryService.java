package com.library.service;

import com.library.model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Сервис-обертка для интеграции TLibrary с JavaFX.
 * Делегирует операции объекту TLibrary.
 */
public class LibraryService {

    /** Объект библиотеки */
    private final TLibrary library;

    /** Observable списки для JavaFX (кэш) */
    private final ObservableList<TBook> booksObservable;
    private final ObservableList<TJournal> journalsObservable;
    private final ObservableList<TReaderCard> readersObservable;

    /** Singleton */
    private static LibraryService instance;

    private LibraryService() {
        library = new TLibrary("Городская библиотека");
        booksObservable = FXCollections.observableArrayList();
        journalsObservable = FXCollections.observableArrayList();
        readersObservable = FXCollections.observableArrayList();
        initTestData();
    }

    public static synchronized LibraryService getInstance() {
        if (instance == null) {
            instance = new LibraryService();
        }
        return instance;
    }

    /**
     * Инициализация тестовых данных.
     */
    private void initTestData() {
        // Книги
        TBook book1 = new TBook(library.generateId(), "Война и мир", "Л.Н. Толстой", "978-5-17-090001-1", 1225);
        TBook book2 = new TBook(library.generateId(), "Преступление и наказание", "Ф.М. Достоевский", "978-5-17-090002-2", 608);
        TBook book3 = new TBook(library.generateId(), "Мастер и Маргарита", "М.А. Булгаков", "978-5-17-090003-3", 480);
        TBook book4 = new TBook(library.generateId(), "Евгений Онегин", "А.С. Пушкин", "978-5-17-090004-4", 224);
        TBook book5 = new TBook(library.generateId(), "Отцы и дети", "И.С. Тургенев", "978-5-17-090005-5", 256);

        library.registerBook(book1);
        library.registerBook(book2);
        library.registerBook(book3);
        library.registerBook(book4);
        library.registerBook(book5);

        // Журналы
        TJournal j1 = new TJournal(library.generateId(), "Наука и жизнь", 12, "Правда");
        TJournal j2 = new TJournal(library.generateId(), "Вокруг света", 5, "Вокруг света");
        TJournal j3 = new TJournal(library.generateId(), "National Geographic", 8, "NG Russia");

        library.registerJournal(j1);
        library.registerJournal(j2);
        library.registerJournal(j3);

        // Читатели
        TReaderCard r1 = new TReaderCard(library.generateId(), "Иванов Иван Иванович", 5);
        TReaderCard r2 = new TReaderCard(library.generateId(), "Петрова Мария Сергеевна", 3);
        TReaderCard r3 = new TReaderCard(library.generateId(), "Сидоров Алексей Петрович", 7);

        library.registerReader(r1);
        library.registerReader(r2);
        library.registerReader(r3);

        refreshObservableLists();
    }

    /**
     * Синхронизирует ObservableList с данными из TLibrary.
     */
    private void refreshObservableLists() {
        booksObservable.setAll(library.getBooks());
        journalsObservable.setAll(library.getJournals());
        readersObservable.setAll(library.getReaders());
    }

    public String generateId() {
        return library.generateId();
    }

    // === Операции с книгами ===

    public ObservableList<TBook> getBooks() {
        return booksObservable;
    }

    public void registerBook(TBook book) {
        if (book.getId() == null || book.getId().isEmpty()) {
            book.setId(library.generateId());
        }
        library.registerBook(book);
        booksObservable.setAll(library.getBooks());
    }

    public void removeBook(TBook book) {
        library.removeBook(book);
        booksObservable.setAll(library.getBooks());
    }

    // === Операции с журналами ===

    public ObservableList<TJournal> getJournals() {
        return journalsObservable;
    }

    public void registerJournal(TJournal journal) {
        if (journal.getId() == null || journal.getId().isEmpty()) {
            journal.setId(library.generateId());
        }
        library.registerJournal(journal);
        journalsObservable.setAll(library.getJournals());
    }

    public void removeJournal(TJournal journal) {
        library.removeJournal(journal);
        journalsObservable.setAll(library.getJournals());
    }

    // === Операции с читателями ===

    public ObservableList<TReaderCard> getReaders() {
        return readersObservable;
    }

    public void registerReader(TReaderCard reader) {
        if (reader.getId() == null || reader.getId().isEmpty()) {
            reader.setId(library.generateId());
        }
        library.registerReader(reader);
        readersObservable.setAll(library.getReaders());
    }

    public void removeReader(TReaderCard reader) {
        library.removeReader(reader);
        readersObservable.setAll(library.getReaders());
    }

    // === Операции выдачи/возврата ===

    /**
     * Выдает единицу читателю через библиотеку.
     */
    public IssueResult issueItem(TLibraryItem item, TReaderCard reader) {
        IssueResult result = library.issueItem(item, reader);
        refreshObservableLists();
        return result;
    }

    /**
     * Возвращает единицу через библиотеку.
     */
    public int returnItem(TLibraryItem item, TReaderCard reader) {
        int penalty = library.returnItem(item, reader);
        refreshObservableLists();
        return penalty;
    }

    // === Поиск ===

    public ObservableList<TLibraryItem> getAvailableItems() {
        return FXCollections.observableArrayList(library.getAvailableItems());
    }

    public ObservableList<TLibraryItem> getAllItems() {
        return FXCollections.observableArrayList(library.getAllItems());
    }

    public ObservableList<TBook> searchBooks(String query) {
        return FXCollections.observableArrayList(library.searchBooks(query));
    }

    public ObservableList<TReaderCard> searchReaders(String query) {
        return FXCollections.observableArrayList(library.searchReaders(query));
    }

    /**
     * Обновляет отображение таблиц.
     */
    public void refresh() {
        refreshObservableLists();
    }

    /**
     * Получает объект библиотеки.
     */
    public TLibrary getLibrary() {
        return library;
    }
}
