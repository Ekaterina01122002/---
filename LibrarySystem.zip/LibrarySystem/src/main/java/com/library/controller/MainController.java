package com.library.controller;

import com.library.model.*;
import com.library.service.LibraryService;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.net.URL;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Главный контроллер приложения.
 */
public class MainController implements Initializable {

    // === Компоненты вкладки "Книги" ===
    @FXML private TableView<TBook> booksTable;
    @FXML private TableColumn<TBook, String> bookIdCol;
    @FXML private TableColumn<TBook, String> bookTitleCol;
    @FXML private TableColumn<TBook, String> bookAuthorCol;
    @FXML private TableColumn<TBook, String> bookIsbnCol;
    @FXML private TableColumn<TBook, Integer> bookPagesCol;
    @FXML private TableColumn<TBook, String> bookStatusCol;

    // === Компоненты вкладки "Журналы" ===
    @FXML private TableView<TJournal> journalsTable;
    @FXML private TableColumn<TJournal, String> journalIdCol;
    @FXML private TableColumn<TJournal, String> journalNameCol;
    @FXML private TableColumn<TJournal, Integer> journalIssueCol;
    @FXML private TableColumn<TJournal, String> journalPublisherCol;
    @FXML private TableColumn<TJournal, String> journalStatusCol;

    // === Компоненты вкладки "Читатели" ===
    @FXML private TableView<TReaderCard> readersTable;
    @FXML private TableColumn<TReaderCard, String> readerIdCol;
    @FXML private TableColumn<TReaderCard, String> readerNameCol;
    @FXML private TableColumn<TReaderCard, String> readerDateCol;
    @FXML private TableColumn<TReaderCard, Integer> readerBorrowedCol;
    @FXML private TableColumn<TReaderCard, Integer> readerMaxCol;

    // === Компоненты вкладки "Выдача" ===
    @FXML private TableView<TLibraryItem> issueItemsTable;
    @FXML private TableColumn<TLibraryItem, String> issueItemIdCol;
    @FXML private TableColumn<TLibraryItem, String> issueItemNameCol;
    @FXML private TableColumn<TLibraryItem, String> issueItemStatusCol;

    @FXML private TableView<TReaderCard> issueReadersTable;
    @FXML private TableColumn<TReaderCard, String> issueReaderIdCol;
    @FXML private TableColumn<TReaderCard, String> issueReaderNameCol;
    @FXML private TableColumn<TReaderCard, String> issueReaderBorrowedCol;

    @FXML private ComboBox<String> itemFilterCombo;
    @FXML private DatePicker returnDatePicker;
    @FXML private Label penaltyLabel;

    @FXML private TextField searchField;

    private LibraryService libraryService;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        libraryService = LibraryService.getInstance();

        setupBooksTable();
        setupJournalsTable();
        setupReadersTable();
        setupIssueTab();

        returnDatePicker.setValue(LocalDate.now().plusDays(14));
    }


    private void setupBooksTable() {
        bookIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        bookTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        bookAuthorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        bookIsbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        bookPagesCol.setCellValueFactory(new PropertyValueFactory<>("pages"));
        bookStatusCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus().getDisplayName()));

        booksTable.setItems(libraryService.getBooks());
    }

    private void setupJournalsTable() {
        journalIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        journalNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        journalIssueCol.setCellValueFactory(new PropertyValueFactory<>("issueNumber"));
        journalPublisherCol.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        journalStatusCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus().getDisplayName()));

        journalsTable.setItems(libraryService.getJournals());
    }

    private void setupReadersTable() {
        readerIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        readerNameCol.setCellValueFactory(new PropertyValueFactory<>("readerName"));
        readerDateCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getRegistrationDate().toString()));
        readerBorrowedCol.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getBorrowedCount()).asObject());
        readerMaxCol.setCellValueFactory(new PropertyValueFactory<>("maxBooks"));

        readersTable.setItems(libraryService.getReaders());
    }

    private void setupIssueTab() {
        issueItemIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        issueItemNameCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getDisplayName()));
        issueItemStatusCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus().getDisplayName()));

        issueReaderIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        issueReaderNameCol.setCellValueFactory(new PropertyValueFactory<>("readerName"));
        issueReaderBorrowedCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getBorrowedCount() + "/" +
                                        cellData.getValue().getMaxBooks()));

        itemFilterCombo.setItems(FXCollections.observableArrayList("Все", "Книги", "Журналы"));
        itemFilterCombo.setValue("Все");
        itemFilterCombo.setOnAction(e -> filterItems());

        refreshIssueTables();
    }

    private void filterItems() {
        String filter = itemFilterCombo.getValue();
        ObservableList<TLibraryItem> filtered = FXCollections.observableArrayList();

        switch (filter) {
            case "Книги":
                for (TBook b : libraryService.getBooks()) {
                    if (b.getStatus() == ItemStatus.AVAILABLE) {
                        filtered.add(b);
                    }
                }
                break;
            case "Журналы":
                for (TJournal j : libraryService.getJournals()) {
                    if (j.getStatus() == ItemStatus.AVAILABLE) {
                        filtered.add(j);
                    }
                }
                break;
            default:
                filtered = libraryService.getAvailableItems();
        }

        issueItemsTable.setItems(filtered);
    }

    private void refreshIssueTables() {
        issueItemsTable.setItems(libraryService.getAvailableItems());
        issueReadersTable.setItems(libraryService.getReaders());
    }


    @FXML
    private void handleAddBook() {
        Dialog<TBook> dialog = createBookDialog(null);
        Optional<TBook> result = dialog.showAndWait();
        result.ifPresent(book -> {
            libraryService.registerBook(book);
            booksTable.refresh();
        });
    }

    @FXML
    private void handleEditBook() {
        TBook selected = booksTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Ошибка", "Выберите книгу для редактирования", Alert.AlertType.WARNING);
            return;
        }

        Dialog<TBook> dialog = createBookDialog(selected);
        Optional<TBook> result = dialog.showAndWait();
        result.ifPresent(book -> {
            libraryService.refresh();
            booksTable.refresh();
        });
    }

    @FXML
    private void handleDeleteBook() {
        TBook selected = booksTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Ошибка", "Выберите книгу для удаления", Alert.AlertType.WARNING);
            return;
        }

        if (selected.getStatus() == ItemStatus.ISSUED) {
            showAlert("Ошибка", "Невозможно удалить выданную книгу", Alert.AlertType.ERROR);
            return;
        }

        if (confirmDelete("книгу \"" + selected.getTitle() + "\"")) {
            libraryService.removeBook(selected);
            refreshIssueTables();
        }
    }


    @FXML
    private void handleAddJournal() {
        Dialog<TJournal> dialog = createJournalDialog(null);
        Optional<TJournal> result = dialog.showAndWait();
        result.ifPresent(journal -> {
            libraryService.registerJournal(journal);
            journalsTable.refresh();
            refreshIssueTables();
        });
    }

    @FXML
    private void handleEditJournal() {
        TJournal selected = journalsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Ошибка", "Выберите журнал для редактирования", Alert.AlertType.WARNING);
            return;
        }

        Dialog<TJournal> dialog = createJournalDialog(selected);
        Optional<TJournal> result = dialog.showAndWait();
        result.ifPresent(journal -> {
            libraryService.refresh();
            journalsTable.refresh();
        });
    }

    @FXML
    private void handleDeleteJournal() {
        TJournal selected = journalsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Ошибка", "Выберите журнал для удаления", Alert.AlertType.WARNING);
            return;
        }

        if (selected.getStatus() == ItemStatus.ISSUED) {
            showAlert("Ошибка", "Невозможно удалить выданный журнал", Alert.AlertType.ERROR);
            return;
        }

        if (confirmDelete("журнал \"" + selected.getName() + "\"")) {
            libraryService.removeJournal(selected);
            refreshIssueTables();
        }
    }


    @FXML
    private void handleAddReader() {
        Dialog<TReaderCard> dialog = createReaderDialog(null);
        Optional<TReaderCard> result = dialog.showAndWait();
        result.ifPresent(reader -> {
            libraryService.registerReader(reader);
            readersTable.refresh();
            refreshIssueTables();
        });
    }

    @FXML
    private void handleEditReader() {
        TReaderCard selected = readersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Ошибка", "Выберите читателя для редактирования", Alert.AlertType.WARNING);
            return;
        }

        Dialog<TReaderCard> dialog = createReaderDialog(selected);
        Optional<TReaderCard> result = dialog.showAndWait();
        result.ifPresent(reader -> {
            libraryService.refresh();
            readersTable.refresh();
        });
    }

    @FXML
    private void handleDeleteReader() {
        TReaderCard selected = readersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Ошибка", "Выберите читателя для удаления", Alert.AlertType.WARNING);
            return;
        }

        if (selected.getBorrowedCount() > 0) {
            showAlert("Ошибка", "Невозможно удалить читателя с книгами на руках", Alert.AlertType.ERROR);
            return;
        }

        if (confirmDelete("читателя \"" + selected.getReaderName() + "\"")) {
            libraryService.removeReader(selected);
            refreshIssueTables();
        }
    }


    @FXML
    private void handleIssue() {
        TLibraryItem item = issueItemsTable.getSelectionModel().getSelectedItem();
        TReaderCard reader = issueReadersTable.getSelectionModel().getSelectedItem();

        if (item == null) {
            showAlert("Ошибка", "Выберите единицу для выдачи", Alert.AlertType.WARNING);
            return;
        }

        if (reader == null) {
            showAlert("Ошибка", "Выберите читателя", Alert.AlertType.WARNING);
            return;
        }

        IssueResult result = libraryService.issueItem(item, reader);

        if (result.success()) {
            showAlert("Успех", result.message(), Alert.AlertType.INFORMATION);
            refreshAllTables();
        } else {
            showAlert("Ошибка выдачи", result.message(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleReturn() {
        TReaderCard reader = issueReadersTable.getSelectionModel().getSelectedItem();

        if (reader == null) {
            showAlert("Ошибка", "Выберите читателя", Alert.AlertType.WARNING);
            return;
        }

        if (reader.getBorrowedCount() == 0) {
            showAlert("Информация", "У читателя нет книг на руках", Alert.AlertType.INFORMATION);
            return;
        }

        // Получаем массив выданных единиц
        TLibraryItem[] borrowedItems = reader.getBorrowedItems();
        ObservableList<TLibraryItem> itemsList = FXCollections.observableArrayList(borrowedItems);

        ChoiceDialog<TLibraryItem> dialog = new ChoiceDialog<>(itemsList.get(0), itemsList);
        dialog.setTitle("Возврат");
        dialog.setHeaderText("Выберите единицу для возврата");
        dialog.setContentText("Единица:");

        Optional<TLibraryItem> result = dialog.showAndWait();
        result.ifPresent(item -> {
            int penalty = libraryService.returnItem(item, reader);

            String message = "Единица возвращена успешно.";
            if (penalty > 0) {
                message += "\nНачислен штраф: " + penalty + " баллов за просрочку.";
            }

            showAlert("Успех", message, Alert.AlertType.INFORMATION);
            refreshAllTables();
        });
    }


    @FXML
    private void handleSearch() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) {
            booksTable.setItems(libraryService.getBooks());
            readersTable.setItems(libraryService.getReaders());
            return;
        }

        booksTable.setItems(libraryService.searchBooks(query));
        readersTable.setItems(libraryService.searchReaders(query));
    }


    private void refreshAllTables() {
        libraryService.refresh();
        booksTable.refresh();
        journalsTable.refresh();
        readersTable.refresh();
        refreshIssueTables();
    }

    private Dialog<TBook> createBookDialog(TBook book) {
        Dialog<TBook> dialog = new Dialog<>();
        dialog.setTitle(book == null ? "Добавить книгу" : "Редактировать книгу");

        ButtonType saveButtonType = new ButtonType("Сохранить", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField titleField = new TextField();
        titleField.setPromptText("Название");
        TextField authorField = new TextField();
        authorField.setPromptText("Автор");
        TextField isbnField = new TextField();
        isbnField.setPromptText("ISBN");
        Spinner<Integer> pagesSpinner = new Spinner<>(1, 10000, 100);
        pagesSpinner.setEditable(true);
        ComboBox<ItemStatus> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll(ItemStatus.AVAILABLE, ItemStatus.IN_REPAIR);
        statusCombo.setValue(ItemStatus.AVAILABLE);

        if (book != null) {
            titleField.setText(book.getTitle());
            authorField.setText(book.getAuthor());
            isbnField.setText(book.getIsbn());
            pagesSpinner.getValueFactory().setValue(book.getPages());
            statusCombo.setValue(book.getStatus());
        }

        grid.add(new Label("Название:"), 0, 0);
        grid.add(titleField, 1, 0);
        grid.add(new Label("Автор:"), 0, 1);
        grid.add(authorField, 1, 1);
        grid.add(new Label("ISBN:"), 0, 2);
        grid.add(isbnField, 1, 2);
        grid.add(new Label("Страниц:"), 0, 3);
        grid.add(pagesSpinner, 1, 3);
        grid.add(new Label("Статус:"), 0, 4);
        grid.add(statusCombo, 1, 4);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                if (titleField.getText().trim().isEmpty() || authorField.getText().trim().isEmpty()) {
                    showAlert("Ошибка", "Заполните обязательные поля", Alert.AlertType.ERROR);
                    return null;
                }

                TBook result = book != null ? book : new TBook(libraryService.generateId(), "", "");
                result.setTitle(titleField.getText().trim());
                result.setAuthor(authorField.getText().trim());
                result.setIsbn(isbnField.getText().trim());
                result.setPages(pagesSpinner.getValue());
                result.setStatus(statusCombo.getValue());
                return result;
            }
            return null;
        });

        return dialog;
    }

    private Dialog<TJournal> createJournalDialog(TJournal journal) {
        Dialog<TJournal> dialog = new Dialog<>();
        dialog.setTitle(journal == null ? "Добавить журнал" : "Редактировать журнал");

        ButtonType saveButtonType = new ButtonType("Сохранить", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nameField = new TextField();
        nameField.setPromptText("Название");
        Spinner<Integer> issueSpinner = new Spinner<>(1, 1000, 1);
        issueSpinner.setEditable(true);
        TextField publisherField = new TextField();
        publisherField.setPromptText("Издательство");
        ComboBox<ItemStatus> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll(ItemStatus.AVAILABLE, ItemStatus.IN_REPAIR);
        statusCombo.setValue(ItemStatus.AVAILABLE);

        if (journal != null) {
            nameField.setText(journal.getName());
            issueSpinner.getValueFactory().setValue(journal.getIssueNumber());
            publisherField.setText(journal.getPublisher());
            statusCombo.setValue(journal.getStatus());
        }

        grid.add(new Label("Название:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Номер выпуска:"), 0, 1);
        grid.add(issueSpinner, 1, 1);
        grid.add(new Label("Издательство:"), 0, 2);
        grid.add(publisherField, 1, 2);
        grid.add(new Label("Статус:"), 0, 3);
        grid.add(statusCombo, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                if (nameField.getText().trim().isEmpty()) {
                    showAlert("Ошибка", "Введите название журнала", Alert.AlertType.ERROR);
                    return null;
                }

                TJournal result = journal != null ? journal : new TJournal(libraryService.generateId(), "", 1);
                result.setName(nameField.getText().trim());
                result.setIssueNumber(issueSpinner.getValue());
                result.setPublisher(publisherField.getText().trim());
                result.setStatus(statusCombo.getValue());
                return result;
            }
            return null;
        });

        return dialog;
    }

    private Dialog<TReaderCard> createReaderDialog(TReaderCard reader) {
        Dialog<TReaderCard> dialog = new Dialog<>();
        dialog.setTitle(reader == null ? "Добавить читателя" : "Редактировать читателя");

        ButtonType saveButtonType = new ButtonType("Сохранить", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nameField = new TextField();
        nameField.setPromptText("ФИО читателя");
        Spinner<Integer> maxBooksSpinner = new Spinner<>(1, 20, 5);
        maxBooksSpinner.setEditable(true);

        if (reader != null) {
            nameField.setText(reader.getReaderName());
            maxBooksSpinner.getValueFactory().setValue(reader.getMaxBooks());
        }

        grid.add(new Label("ФИО:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Макс. книг:"), 0, 1);
        grid.add(maxBooksSpinner, 1, 1);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                if (nameField.getText().trim().isEmpty()) {
                    showAlert("Ошибка", "Введите ФИО читателя", Alert.AlertType.ERROR);
                    return null;
                }

                TReaderCard result = reader != null ? reader : new TReaderCard(libraryService.generateId(), "");
                result.setReaderName(nameField.getText().trim());
                result.setMaxBooks(maxBooksSpinner.getValue());
                return result;
            }
            return null;
        });

        return dialog;
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean confirmDelete(String itemName) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Подтверждение удаления");
        alert.setHeaderText("Удалить " + itemName + "?");
        alert.setContentText("Это действие нельзя отменить.");

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }


    @FXML
    private void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("О программе");
        alert.setHeaderText("Система учета книг и читателей");
        alert.setContentText("Версия 1.0\n\nКурсовой проект по дисциплине\n\"Объектно-ориентированное программирование\"\n\n© 2025");
        alert.showAndWait();
    }

    @FXML
    private void handleExit() {
        System.exit(0);
    }

    /**
     * Создает главный макет приложения программно.
     */
    public TabPane createMainLayout() {
        libraryService = LibraryService.getInstance();

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab booksTab = new Tab("Книги", createBooksTab());
        Tab journalsTab = new Tab("Журналы", createJournalsTab());
        Tab readersTab = new Tab("Читатели", createReadersTab());
        Tab issueTab = new Tab("Выдача/Возврат", createIssueTab());

        tabPane.getTabs().addAll(booksTab, journalsTab, readersTab, issueTab);

        return tabPane;
    }

    private VBox createBooksTab() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        booksTable = new TableView<>();
        bookIdCol = new TableColumn<>("ID");
        bookTitleCol = new TableColumn<>("Название");
        bookAuthorCol = new TableColumn<>("Автор");
        bookIsbnCol = new TableColumn<>("ISBN");
        bookPagesCol = new TableColumn<>("Страниц");
        bookStatusCol = new TableColumn<>("Статус");

        bookIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        bookTitleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        bookAuthorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
        bookIsbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        bookPagesCol.setCellValueFactory(new PropertyValueFactory<>("pages"));
        bookStatusCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus().getDisplayName()));

        bookIdCol.setPrefWidth(80);
        bookTitleCol.setPrefWidth(200);
        bookAuthorCol.setPrefWidth(150);
        bookIsbnCol.setPrefWidth(150);
        bookPagesCol.setPrefWidth(80);
        bookStatusCol.setPrefWidth(100);

        booksTable.getColumns().addAll(bookIdCol, bookTitleCol, bookAuthorCol,
                bookIsbnCol, bookPagesCol, bookStatusCol);
        booksTable.setItems(libraryService.getBooks());
        VBox.setVgrow(booksTable, Priority.ALWAYS);

        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        TextField bookSearchField = new TextField();
        bookSearchField.setPromptText("Поиск по названию или автору...");
        bookSearchField.setPrefWidth(300);
        bookSearchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                booksTable.setItems(libraryService.getBooks());
            } else {
                booksTable.setItems(libraryService.searchBooks(newVal));
            }
        });
        searchBox.getChildren().addAll(new Label("Поиск:"), bookSearchField);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_LEFT);
        Button addBtn = new Button("Добавить");
        Button editBtn = new Button("Редактировать");
        Button deleteBtn = new Button("Удалить");

        addBtn.setOnAction(e -> handleAddBook());
        editBtn.setOnAction(e -> handleEditBook());
        deleteBtn.setOnAction(e -> handleDeleteBook());

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn);

        content.getChildren().addAll(searchBox, booksTable, buttonBox);
        return content;
    }

    private VBox createJournalsTab() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        journalsTable = new TableView<>();
        journalIdCol = new TableColumn<>("ID");
        journalNameCol = new TableColumn<>("Название");
        journalIssueCol = new TableColumn<>("Номер");
        journalPublisherCol = new TableColumn<>("Издательство");
        journalStatusCol = new TableColumn<>("Статус");

        journalIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        journalNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        journalIssueCol.setCellValueFactory(new PropertyValueFactory<>("issueNumber"));
        journalPublisherCol.setCellValueFactory(new PropertyValueFactory<>("publisher"));
        journalStatusCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus().getDisplayName()));

        journalIdCol.setPrefWidth(80);
        journalNameCol.setPrefWidth(200);
        journalIssueCol.setPrefWidth(80);
        journalPublisherCol.setPrefWidth(150);
        journalStatusCol.setPrefWidth(100);

        journalsTable.getColumns().addAll(journalIdCol, journalNameCol, journalIssueCol,
                journalPublisherCol, journalStatusCol);
        journalsTable.setItems(libraryService.getJournals());
        VBox.setVgrow(journalsTable, Priority.ALWAYS);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_LEFT);
        Button addBtn = new Button("Добавить");
        Button editBtn = new Button("Редактировать");
        Button deleteBtn = new Button("Удалить");

        addBtn.setOnAction(e -> handleAddJournal());
        editBtn.setOnAction(e -> handleEditJournal());
        deleteBtn.setOnAction(e -> handleDeleteJournal());

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn);

        content.getChildren().addAll(journalsTable, buttonBox);
        return content;
    }

    private VBox createReadersTab() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        readersTable = new TableView<>();
        readerIdCol = new TableColumn<>("ID");
        readerNameCol = new TableColumn<>("ФИО");
        readerDateCol = new TableColumn<>("Дата регистрации");
        readerBorrowedCol = new TableColumn<>("Книг на руках");
        readerMaxCol = new TableColumn<>("Макс. книг");

        readerIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        readerNameCol.setCellValueFactory(new PropertyValueFactory<>("readerName"));
        readerDateCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getRegistrationDate().toString()));
        readerBorrowedCol.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getBorrowedCount()).asObject());
        readerMaxCol.setCellValueFactory(new PropertyValueFactory<>("maxBooks"));

        readerIdCol.setPrefWidth(80);
        readerNameCol.setPrefWidth(250);
        readerDateCol.setPrefWidth(120);
        readerBorrowedCol.setPrefWidth(100);
        readerMaxCol.setPrefWidth(100);

        readersTable.getColumns().addAll(readerIdCol, readerNameCol, readerDateCol,
                readerBorrowedCol, readerMaxCol);
        readersTable.setItems(libraryService.getReaders());
        VBox.setVgrow(readersTable, Priority.ALWAYS);

        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        TextField readerSearchField = new TextField();
        readerSearchField.setPromptText("Поиск по ФИО...");
        readerSearchField.setPrefWidth(300);
        readerSearchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                readersTable.setItems(libraryService.getReaders());
            } else {
                readersTable.setItems(libraryService.searchReaders(newVal));
            }
        });
        searchBox.getChildren().addAll(new Label("Поиск:"), readerSearchField);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_LEFT);
        Button addBtn = new Button("Добавить");
        Button editBtn = new Button("Редактировать");
        Button deleteBtn = new Button("Удалить");

        addBtn.setOnAction(e -> handleAddReader());
        editBtn.setOnAction(e -> handleEditReader());
        deleteBtn.setOnAction(e -> handleDeleteReader());

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn);

        content.getChildren().addAll(searchBox, readersTable, buttonBox);
        return content;
    }

    private VBox createIssueTab() {
        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        issueItemsTable = new TableView<>();
        issueItemIdCol = new TableColumn<>("ID");
        issueItemNameCol = new TableColumn<>("Наименование");
        issueItemStatusCol = new TableColumn<>("Статус");

        issueItemIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        issueItemNameCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getDisplayName()));
        issueItemStatusCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus().getDisplayName()));

        issueItemIdCol.setPrefWidth(80);
        issueItemNameCol.setPrefWidth(300);
        issueItemStatusCol.setPrefWidth(100);

        issueItemsTable.getColumns().addAll(issueItemIdCol, issueItemNameCol, issueItemStatusCol);
        issueItemsTable.setItems(libraryService.getAllItems());

        issueReadersTable = new TableView<>();
        issueReaderIdCol = new TableColumn<>("ID");
        issueReaderNameCol = new TableColumn<>("ФИО читателя");
        issueReaderBorrowedCol = new TableColumn<>("Книг на руках");

        issueReaderIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        issueReaderNameCol.setCellValueFactory(new PropertyValueFactory<>("readerName"));
        issueReaderBorrowedCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getBorrowedCount() +
                        " / " + cellData.getValue().getMaxBooks()));

        issueReaderIdCol.setPrefWidth(80);
        issueReaderNameCol.setPrefWidth(200);
        issueReaderBorrowedCol.setPrefWidth(100);

        issueReadersTable.getColumns().addAll(issueReaderIdCol, issueReaderNameCol, issueReaderBorrowedCol);
        issueReadersTable.setItems(libraryService.getReaders());

        itemFilterCombo = new ComboBox<>();
        itemFilterCombo.getItems().addAll("Все", "Только доступные", "Только книги", "Только журналы");
        itemFilterCombo.setValue("Все");
        itemFilterCombo.setOnAction(e -> applyItemFilter());

        HBox controlBox = new HBox(10);
        controlBox.setAlignment(Pos.CENTER_LEFT);
        returnDatePicker = new DatePicker(LocalDate.now().plusDays(14));
        penaltyLabel = new Label("Штраф: 0");
        Button issueBtn = new Button("Выдать");
        Button returnBtn = new Button("Вернуть");

        issueBtn.setOnAction(e -> handleIssue());
        returnBtn.setOnAction(e -> handleReturn());

        controlBox.getChildren().addAll(new Label("Фильтр:"), itemFilterCombo,
                new Label("Дата возврата:"), returnDatePicker,
                issueBtn, returnBtn, penaltyLabel);

        SplitPane splitPane = new SplitPane();
        VBox itemsBox = new VBox(5, new Label("Библиотечные единицы:"), issueItemsTable);
        VBox readersBox = new VBox(5, new Label("Читатели:"), issueReadersTable);
        VBox.setVgrow(issueItemsTable, Priority.ALWAYS);
        VBox.setVgrow(issueReadersTable, Priority.ALWAYS);
        splitPane.getItems().addAll(itemsBox, readersBox);
        splitPane.setDividerPositions(0.6);
        VBox.setVgrow(splitPane, Priority.ALWAYS);

        content.getChildren().addAll(controlBox, splitPane);
        return content;
    }

    private void applyItemFilter() {
        String filter = itemFilterCombo.getValue();
        ObservableList<TLibraryItem> items;

        switch (filter) {
            case "Только доступные":
                items = libraryService.getAvailableItems();
                break;
            case "Только книги":
                items = FXCollections.observableArrayList();
                items.addAll(libraryService.getBooks());
                break;
            case "Только журналы":
                items = FXCollections.observableArrayList();
                items.addAll(libraryService.getJournals());
                break;
            default:
                items = libraryService.getAllItems();
        }
        issueItemsTable.setItems(items);
    }
}
