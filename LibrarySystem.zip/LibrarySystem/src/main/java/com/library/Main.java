package com.library;

import com.library.controller.MainController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * Главный класс приложения "Система учета библиотеки".
 * Точка входа в JavaFX приложение.
 * 
 */
public class Main extends Application {
    
    /** Ширина окна по умолчанию */
    private static final int DEFAULT_WIDTH = 1024;
    
    /** Высота окна по умолчанию */
    private static final int DEFAULT_HEIGHT = 768;
    
    /**
     * Главный метод приложения.
     * 
     * @param args аргументы командной строки
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    /**
     * Инициализация и запуск JavaFX приложения.
     * 
     * @param primaryStage главное окно приложения
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            // Создание корневого контейнера
            BorderPane root = new BorderPane();
            
            // Создание и инициализация контроллера
            MainController controller = new MainController();
            root.setCenter(controller.createMainLayout());
            
            // Создание сцены
            Scene scene = new Scene(root, DEFAULT_WIDTH, DEFAULT_HEIGHT);
            
            try {
                var cssUrl = getClass().getResource("/styles/application.css");
                if (cssUrl != null) {
                    scene.getStylesheets().add(cssUrl.toExternalForm());
                }
            } catch (Exception cssEx) {
                System.err.println("CSS не загружен: " + cssEx.getMessage());
            }
            
            // Настройка главного окна
            primaryStage.setTitle("Система учета библиотеки");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(800);
            primaryStage.setMinHeight(600);
            
            // Отображение окна
            primaryStage.show();
            
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Ошибка запуска приложения: " + e.getMessage());
        }
    }
}
